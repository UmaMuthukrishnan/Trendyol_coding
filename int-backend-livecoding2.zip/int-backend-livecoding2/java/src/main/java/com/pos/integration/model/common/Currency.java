package com.pos.integration.model.common;

public enum Currency {
    TRY,
    USD,
    EUR;
}
