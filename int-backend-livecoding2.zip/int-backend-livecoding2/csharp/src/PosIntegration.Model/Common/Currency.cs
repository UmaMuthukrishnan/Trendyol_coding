namespace PosIntegration.Model.Common
{
    public enum Currency
    {
        TRY,
        USD,
        EUR
    }
}