namespace PosIntegration.Model
{
    public class PostResponse<T>
    {
        public T Response { get; set; }
    }
}