package com.trendyol.posintegrationapi

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class PosIntegrationApiPosIntegrationApiTests {

    @Test
    fun contextLoads() {
    }
}
