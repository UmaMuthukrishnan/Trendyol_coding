package com.trendyol.posintegrationapi.model.redirect_url

class RedirectUrlResponse(
    var url: String?,
    var rawBody: String?,
)
