package com.trendyol.posintegrationapi.model.common

enum class Currency {
    TRY, USD, EUR
}