package com.trendyol.posintegrationapi.exception

class PosException(message: String?, cause: Throwable?) : Exception(message, cause)