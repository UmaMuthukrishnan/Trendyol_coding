package com.trendyol.posintegrationapi.model.common

class PosCredential {
    var username: String? = null
    var password: String? = null
    var clientId: String? = null
}
