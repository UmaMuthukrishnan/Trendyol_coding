package redirect_url

type RedirectUrlResponse struct {
	Url     string
	RawBody string
}
