package common

type PosCredential struct {
	Username string
	Password string
	ClientId string
}
