package common

type Currency string

const (
	TRY Currency = "TRY"
	USD Currency = "USD"
	EUR Currency = "EUR"
)
