export interface EstRefundResponse {
  response: string;
  errorCode: string;
  message: string;
  rawBody: string;
}
