export interface PosCredential {
  username: string;
  password: string;
  clientId: string;
}
