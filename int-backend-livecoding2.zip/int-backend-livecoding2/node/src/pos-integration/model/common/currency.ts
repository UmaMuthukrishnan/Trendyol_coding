export enum Currency {
  TRY = 0,
  USD = 1,
  EUR = 2,
}
