export class PosResponse<T> {
  private response: T;
}
