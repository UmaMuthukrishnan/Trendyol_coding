export interface RedirectUrlResponse {
  url: string;
  rawBody: string;
}
